"use strict";
{
  const nameProduct = "молоко";
  const productQuantity = 30;
  const productCategory = "продукты";
  const productPrice = 15;
  console.log(
    `Общая сумма товара из категории ${productCategory}, а именно ${nameProduct} равна ${
      productQuantity * productPrice
    } руб`
  );
}
