"use strict";
{
  const nameProduct = "молоко";
  const productQuantity = 30;
  const productCategory = "продукты";
  const productPrice = 15;
  console.log(`Товар ${nameProduct} `);
}
